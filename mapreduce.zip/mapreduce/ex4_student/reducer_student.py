#!/usr/bin/env python

from operator import itemgetter
import sys

current_key = None
sum = 0
count = 0

# input comes from STDIN    
mean = current_key,float(sum) / count

for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	row = line.split("\t")
	(key,value) = row

	try: 
		value = int(value)
	except ValueError:
		continue


	if current_key == (key):
		diff += (value - mean)^2
        count +=1
	else:


if current_key == key:
	print('{}\t{}'.format(current_key,float(diff))